from abc import ABCMeta, abstractmethod

# abstract base class for defining labels
class Label:
    __metaclass__ = ABCMeta

    @abstractmethod
    def __str__(self): pass

       
class ClassificationLabel(Label):
    def __init__(self, label):
        self.label = label
        
    def __str__(self):
        return str(self.label)

class FeatureVector:
    def __init__(self):
        self._fv = {}
        
    def add(self, index, value):
        self._fv[index] = value
        
    def get(self, index):
        return self._fv[index]

    def keys(self):
        return self._fv.keys()

class Instance:
    def __init__(self, feature_vector, label):
        self.feature_vector = feature_vector
        self.label = label

# abstract base class for defining predictors
class Predictor:
    __metaclass__ = ABCMeta

    @abstractmethod
    def train(self, instances): pass

    @abstractmethod
    def predict(self, instance): pass

# Specific predictor class with implemented perceptron algorithms
class PerceptronPredictor:
    def __init__(self, learn_rate, iterations):
        self.weight = {}
        self.learn_rate = learn_rate
        self.iterations = iterations
        self.weight_sum = {} #only used for averaged_perceptron

    #returns true if the Perceptron (using current weight vector) correctly predicts the label
    #false if otherwise
    def predict(self, instance):
        label = instance.label
        fv = instance.feature_vector

        #initialize the sum for the dot_product
        dot_product = 0

        #iterate according to the non-zero values in the weight vector.
        #all other values are zero, so the dot product does not count them.
        for v in fv.keys():
            #Look for w in the feature_vector to see if it exists, if so then add to dot product
            try:
                dot_product += self.weight[v] * fv.get(v)
            except KeyError:
                pass

        #if the dot product sum is >= 0, then the predict_label = 1; otherwise, 0
        if dot_product >= 0:
            return 1
        else:
            return 0

    def train(self, instances, algorithm):

        #train according to the number of iterations given
        for k in range(1, self.iterations):

            #for each iteration of training, loop over each instance
            for instance in instances:
                #get information from the instance
                label = instance.label
                fv = instance.feature_vector

                # predict using the current weight vector
                yhat = self.predict(instance)
                ylabel = label.label #extract the integer label from the ClassificationLabel

                #convert the label given to {-1, 1} for the perceptron algorithm
                if ylabel == 0:
                    y = -1
                else:
                    y = 1

                #compare perceptron prediction to actual ylabel
                if ylabel == yhat:
                    continue
                #if perceptron is wrong, update the weight vector
                else:

                    #for every non-zero key value in the feature vector
                    for v in fv.keys():
                        try:
                            self.weight[v] += self.learn_rate * y * fv.get(v)
                        except KeyError:
                            self.weight[v] = self.learn_rate * y * fv.get(v)

                #if averaged_perceptron is selected, update accordingly
                if algorithm == "averaged_perceptron":
                    #add all the non-zero weight vector values to the cumulating weight_sum vector
                    for w in self.weight.keys():
                        try:
                            self.weight_sum[w] += self.weight[w]
                        except KeyError:
                            self.weight_sum[w] = self.weight[w]

        #at the end of all the training iterations, update the weight vector as the averaged of all training iterations
        if algorithm == "averaged_perceptron":
            self.weight = self.weight_sum
